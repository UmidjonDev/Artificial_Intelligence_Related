import numpy as np

def calculate(list):
    try:
        numpyArray=np.reshape(list, (3,3))
        calculations={
        'mean' : [np.mean(numpyArray, axis=0).tolist(),np.mean(numpyArray, axis=1).tolist(),np.mean(numpyArray)],
        'variance' : [np.var(numpyArray, axis=0).tolist(),np.var(numpyArray, axis=1).tolist(),np.var(numpyArray)],
        'standard deviation' : [np.std(numpyArray, axis=0).tolist(),np.std(numpyArray, axis=1).tolist(),np.std(numpyArray)],
        'max' : [np.max(numpyArray, axis=0).tolist(),np.max(numpyArray, axis=1).tolist(),np.max(numpyArray)],
        'min' : [np.min(numpyArray, axis=0).tolist(),np.min(numpyArray, axis=1).tolist(),np.min(numpyArray)],
        'sum' : [np.sum(numpyArray, axis=0).tolist(),np.sum(numpyArray, axis=1).tolist(),np.sum(numpyArray)]
        }
        return calculations
    except ValueError:
        raise ValueError("List must contain nine numbers.")